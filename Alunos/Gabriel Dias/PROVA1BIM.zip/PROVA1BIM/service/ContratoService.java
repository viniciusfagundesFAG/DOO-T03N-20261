package service;

import model.*;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class ContratoService {
    public static List<Contrato> contratos = new ArrayList<>();

    public static void criarContrato (Inquilino inquilino, Imovel imovel) {
        if (getContratos().size() >= 10) {
            System.out.println("Limite de 10 contratos atingido!");
            return;
        }
        if (!imovel.getIsDisponivel()) {
            System.out.println("Imovel não disponível");
            return;
        }

        Contrato con = new Contrato(inquilino, imovel, LocalDate.now(), null, true);
        contratos.add(con);
        imovel.setIsDisponivel(false);

        System.out.println("Contrato fechado com sucesso!");
    }
    public static void devolverImovel(Contrato con) {
        if (con.getDataFim() != null) {
            System.out.println("Já encerrado");
            return;
        }

        con.setDataFim(LocalDate.now());
        con.getImovel().setIsDisponivel(true);

        System.out.println("Imovel devolvido!");
    }

    public static List<Contrato> getContratos() {
        return contratos;
    }
}