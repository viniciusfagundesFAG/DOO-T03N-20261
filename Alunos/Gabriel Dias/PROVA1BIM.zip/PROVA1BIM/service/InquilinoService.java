package service;

import model.Inquilino;

import java.util.List;
import java.util.ArrayList;

public class InquilinoService {
    public static List <Inquilino> inquilinos = new ArrayList <>();

    public static Inquilino criarInquilino(String nome, String cpf, String fone) {
        Inquilino inquilino = new Inquilino (nome, cpf, fone);
        inquilinos.add(inquilino);
        return inquilino;
    }

    public List <Inquilino> listarInquilinos() {
        return inquilinos;
    }
}
