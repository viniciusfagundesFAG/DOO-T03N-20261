package service;

import model.Casa;

import java.util.List;
import java.util.ArrayList;

public class CasaService {
    public static List<Casa> casas = new ArrayList<>();

    public static Casa criarCasa(String cidade, String bairro, String rua, int numero, double aluguel,
                                 Boolean temQuintal, Boolean isDisponivel) {
        Casa casa = new Casa(cidade, bairro, rua, numero, aluguel, temQuintal, isDisponivel);
        casas.add(casa);
        return casa;
    }

    public List<Casa> listarCasas() {
        return casas;
    }
}