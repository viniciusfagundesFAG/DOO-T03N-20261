package service;

import model.Apartamento;

import java.util.List;
import java.util.ArrayList;

public class ApartamentoService {
    public static List<Apartamento> apartamentos = new ArrayList<>();

    public static Apartamento criarApartamento(String cidade, String bairro, String rua, int numero, double aluguel, int andar, Boolean isDisponivel) {
        Apartamento apartamento = new Apartamento(cidade, bairro, rua, numero, aluguel, andar, isDisponivel);
        apartamentos.add(apartamento);
        return apartamento;
    }

    public List<Apartamento> listarApartamentos() {
        return apartamentos;
    }
}