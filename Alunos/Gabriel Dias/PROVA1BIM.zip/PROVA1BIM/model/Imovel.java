package model;

public abstract class Imovel {
    private String cidade;
    private String bairro;
    private String rua;
    private int numero;
    private double aluguel;
    private Boolean isDisponivel;

    public Imovel(String cidade, String bairro, String rua, int numero, double aluguel, Boolean isDisponivel) {
        this.cidade = cidade;
        this.bairro = bairro;
        this.rua = rua;
        this.aluguel = aluguel;
        this.isDisponivel = isDisponivel;
    }

    public Boolean getIsDisponivel() {
        return isDisponivel;
    }

    public void setIsDisponivel(Boolean isDisponivel) {
        this.isDisponivel = isDisponivel;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }
    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getAluguel() {
        return aluguel;
    }

    public void setAluguel(double aluguel) {
        this.aluguel = aluguel;
    }
    public abstract String apresentar();
}
