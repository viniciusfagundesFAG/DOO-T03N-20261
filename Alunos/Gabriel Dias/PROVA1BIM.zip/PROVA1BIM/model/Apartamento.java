package model;

public class Apartamento extends Imovel {
    private int andar;

    public Apartamento(String cidade, String bairro, String rua, int numero, double aluguel, int andar, Boolean isDisponivel) {
        super(cidade, bairro, rua, numero, aluguel, isDisponivel);
        this.andar = andar;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    @Override
    public String apresentar(){
        return "Cidade: " + super.getCidade() + " | Bairro: " + super.getBairro() + " | Rua: " + super.getRua() +
                "N: " + super.getNumero() + " | Aluguel: " + super.getAluguel() +" | Quintal: " + getAndar();
    }
}
