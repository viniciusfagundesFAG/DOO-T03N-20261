package model;

public class Casa extends Imovel {
    private Boolean temQuintal;

    public Casa(String cidade, String bairro, String rua, int numero, double aluguel, Boolean temQuintal, Boolean isDisponivel) {
        super(cidade, bairro, rua, numero, aluguel, isDisponivel);
        this.temQuintal = temQuintal;
    }

    public Boolean getTemQuintal() {
        return temQuintal;
    }

    public void setTemQuintal(Boolean temQuintal) {
        this.temQuintal = temQuintal;
    }

    @Override
    public String apresentar(){
        return "Cidade: " + super.getCidade() + " | Bairro: " + super.getBairro() + " | Rua: " + super.getRua() +
                "N: " + super.getNumero() + " | Aluguel: " + super.getAluguel() +" | Quintal: " + getTemQuintal();
    }
}
