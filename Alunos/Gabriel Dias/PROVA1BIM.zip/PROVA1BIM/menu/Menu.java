package menu;

import model.*;
import service.*;

import java.time.LocalDate;
import java.util.Scanner;

public class Menu {
    static Scanner sc = new Scanner(System.in);
    static ApartamentoService apartamentoService = new ApartamentoService();
    static CasaService casaService = new CasaService();
    static ContratoService contratoService = new ContratoService();
    static InquilinoService inquilinoService = new InquilinoService();

    public static void exibirMenu() {
        int opcao;
        do {
            System.out.println("-------IMOBILIARIA-------");
            System.out.println("    Escolha uma opcao    ");
            System.out.println("1. Cadastrar inquilino");
            System.out.println("2. Cadastrar imovel");
            System.out.println("3. Cadastrar contrato");
            System.out.println("4. Encerrar contrato");
            System.out.println("5. Listar contratos ativos");
            System.out.println("6. Demonstracao");
            System.out.println("0-Sair");
            opcao = sc.nextInt();
            sc.nextLine();
            switch (opcao) {
                case 1 -> {
                    cadastrarInquilino();
                }
                case 2 -> {
                    cadastrarImovel();
                }
                case 3 -> {
                    cadastrarContrato();
                }
                case 4 -> {
                    encerrarContrato();
                }
                case 5 -> {
                    listarContratos();
                }
                case 6 -> {
                    demo();
                }
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0);
    }

    private static void demo() {
        System.out.println("===== DEMONSTRAÇÃO =====");

        Inquilino I1 = InquilinoService.criarInquilino("João Silva", "11155566633", "(45)99999-6699");
        Inquilino I2 = InquilinoService.criarInquilino("Maria Souza", "22277788896", "(46)98882-3584");

        Casa casa = CasaService.criarCasa("Toledo", "jd coopagro", "dos bobos", 0, 500, true, true);
        Apartamento apartamento = ApartamentoService.criarApartamento("Bogota", "Calipso", "de pedra", 105, 900, 10, true );

        ContratoService.criarContrato(I1, casa);
        ContratoService.criarContrato(I2, apartamento);

        Contrato con1 = ContratoService.getContratos().get(0);
        Contrato con2 = ContratoService.getContratos().get(1);

        ContratoService.devolverImovel(con1);

        System.out.println("\n--- Contratos abertos ---");

        for (Contrato t : ContratoService.getContratos()) {
            if (t.getDataFim() == null) {
                System.out.println("Inquilino: " + t.getInquilino().getNome()
                        + " | Imovel: " + t.getImovel().getRua()
                        + " | Data: " + t.getDataInicio());
            }
        }
    }


    private static void listarContratos() {
        var lista = ContratoService.getContratos();

        for (int i = 0; i < lista.size(); i++) {
            var e = lista.get(i);
            System.out.println(i + " - Inquilino: " + e.getInquilino().getNome()
                    + " | Imovel: " + e.getImovel().apresentar()
                    + " | Data incio do contrato: " + e.getDataInicio()
                    + " | Encerrado: " + (e.getDataFim() != null));
        }

    }
    private static void encerrarContrato() {
        var lista = ContratoService.getContratos();

        if (lista.isEmpty()) {
            System.out.println("Nenhum contrato cadastrado!");
            return;
        }

        System.out.println("Selecione o contrato a encerrar:");
        for (int i = 0; i < lista.size(); i++) {
            var e = lista.get(i);
            System.out.println(i + " - Inquilino: " + e.getInquilino().getNome()
                    + " | Imovel: " + e.getImovel().apresentar()
                    + " | Encerrado: " + (e.getDataFim() != null));
        }

        int index = sc.nextInt();
        sc.nextLine();

        Contrato con = lista.get(index);
        if (con.getDataFim() != null) {
            System.out.println("Contrato já encerrado!");
            return;
        }
        con.setDataFim(LocalDate.now());
        con.getImovel().setIsDisponivel(true);
        System.out.println("Contrato encerrado!");
    }


    private static void cadastrarInquilino() {
        System.out.println("Digite o nome do inquilino:");
        String nome = sc.nextLine();
        System.out.println("Digite o cpf do inquilino:");
        String cpf = sc.nextLine();
        System.out.println("Digite o fone do inquilino:");
        String fone = sc.nextLine();
        InquilinoService.criarInquilino(nome, cpf, fone);
        System.out.println("Leitor cadastrado com sucesso!");
    }

    private static void cadastrarImovel() {
        int tipo;
        System.out.println("É um apartamento ou casa?");
        System.out.println("1. Cadastrar apartamento");
        System.out.println("2. Cadastrar casa");
        System.out.println("3. Cancelar");
        tipo = sc.nextInt();
        sc.nextLine();
        switch (tipo) {
            case 1 -> {
                cadastrarApartamento();
            }
            case 2 -> {
                cadastrarCasa();
            }
            default -> {
                System.out.println("Operação cancelada.");
            }

        }
    }

    private static void cadastrarCasa() {
        System.out.println("Digite a cidade da casa");
        String cidade = sc.nextLine();
        System.out.println("Digite o bairro da casa:");
        String bairro = sc.nextLine();
        System.out.println("Digite a rua da casa: ");
        String rua = sc.nextLine();
        System.out.println("Digite o numero da casa: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.println("Digite o valor do aluguel: ");
        double aluguel = sc.nextDouble();
        sc.nextLine();
        System.out.println("Essa casa tem quintal?");
        Boolean temQuintal = funcQuintal();
        System.out.println("Esta disponivel?");
        Boolean isDisponivel = funcDisponivel();
        CasaService.criarCasa(cidade, bairro, rua, numero, aluguel, temQuintal, isDisponivel);
        System.out.println("Imovel cadastrado com sucesso!");

    }
    private static Boolean funcDisponivel() {
        int resp = 0;
        System.out.println("Digite 1 para SIM ou 2 para NÃO");
        resp = sc.nextInt();
        sc.nextLine();
        if (resp == 1) {
            return true;
        }if (resp == 2) {
            return false;
        }else {
            System.out.println("Resposta invalida!");
            return funcDisponivel();
        }
    }

    private static Boolean funcQuintal() {
        int resp = 0;
        System.out.println("Digite 1 para SIM ou 2 para NÃO");
        resp = sc.nextInt();
        sc.nextLine();
        if (resp == 1) {
            return true;
        }
        if (resp == 2) {
            return false;
        } else {
            System.out.println("Resposta invalida!");
            return funcQuintal();
        }
    }

    private static void cadastrarApartamento() {
        System.out.println("Digite a cidade do apartamento: ");
        String cidade = sc.nextLine();
        System.out.println("Digite o bairro do apartamento:");
        String bairro = sc.nextLine();
        System.out.println("Digite a rua do apartamento: ");
        String rua = sc.nextLine();
        System.out.println("Digite o numero do apartamento: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.println("Digite o valor do aluguel: ");
        double aluguel = sc.nextDouble();
        sc.nextLine();
        System.out.println("Qual e o andar desse apartamento");
        int andar = sc.nextInt();
        sc.nextLine();
        System.out.println("Esta disponivel?");
        Boolean isDisponivel = funcDisponivel();
        ApartamentoService.criarApartamento(cidade, bairro, rua, numero, aluguel, andar, isDisponivel);
        System.out.println("Apartamento cadastrado com sucesso!");
    }

    private static void cadastrarContrato() {
        System.out.println("Selecione um Inquilino:");
        for (int i = 0; i < InquilinoService.inquilinos.size(); i++) {
            System.out.println(i + " - " + InquilinoService.inquilinos.get(i).getNome());
        }
        int inquilinoIndex = sc.nextInt();
        sc.nextLine();

        System.out.println("Selecione um item:");

        int count = 0;

        for (Casa l : CasaService.casas) {
            System.out.println(count++ + " - Dados: " + l.apresentar());
        }

        for (Apartamento r : ApartamentoService.apartamentos) {
            System.out.println(count++ + " - Revista: " + r.apresentar());
        }

        int itemIndex = sc.nextInt();
        sc.nextLine();

        Imovel imovelSelecionado;

        if (itemIndex < CasaService.casas.size()) {
            imovelSelecionado = CasaService.casas.get(itemIndex);
        } else {
            imovelSelecionado = ApartamentoService.apartamentos
                    .get(itemIndex - CasaService.casas.size());
        }

        ContratoService.criarContrato(
                InquilinoService.inquilinos.get(inquilinoIndex),
                imovelSelecionado
        );
    }
}

